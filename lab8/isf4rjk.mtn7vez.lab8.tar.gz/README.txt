Me and my partner were not able to complete this assignment due to the overwhelming
amount of work we had this week (including the quiz and final for just this class).
I'll just say that we got a mostly working implementation of create and extract;
it'd be really great to get partial credit for that because we put a lot of effort
into what we have, and having the most difficult and laborous assignment of the
semester be due during finals week was really stressful.