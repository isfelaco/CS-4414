//
// Created by isf4rjk on 9/19/23.
// create a new program to run your writecount call and print the results
//
#include "types.h"
#include "stat.h"
#include "user.h"

int
main(int argc, char *argv[])
{
    printf(1, "%d \n", writecount());
    exit();
}

